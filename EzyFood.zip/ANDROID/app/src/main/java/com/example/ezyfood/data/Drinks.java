package com.example.ezyfood.data;

import com.example.ezyfood.models.Drink;
import com.example.ezyfood.models.Item;

import java.util.ArrayList;

public class Drinks {
    public static ArrayList<Item> getDrinks() {
        ArrayList<Item> drinks = new ArrayList<>();
        drinks.add(new Drink("Mineral Water", 6000));
        drinks.add(new Drink("Orange Juice", 15000));
        drinks.add(new Drink("Thai Tea", 25000));

        return drinks;
    }
}
