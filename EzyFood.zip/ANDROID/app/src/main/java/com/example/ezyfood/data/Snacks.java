package com.example.ezyfood.data;

import com.example.ezyfood.models.Item;
import com.example.ezyfood.models.Snack;

import java.util.ArrayList;

public class Snacks {
    public static ArrayList<Item> getSnacks() {
        ArrayList<Item> snacks = new ArrayList<>();
        snacks.add(new Snack("Mineral Water", 6000));
        snacks.add(new Snack("Orange Juice", 15000));
        snacks.add(new Snack("Thai Tea", 25000));

        return snacks;
    }
}
