package com.example.ezyfood.models;

public class Snack extends Item {
    public Snack(String name, int price) {
        super(name, price);
    }
}
