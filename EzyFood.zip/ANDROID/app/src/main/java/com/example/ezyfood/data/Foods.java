package com.example.ezyfood.data;

import com.example.ezyfood.models.Food;
import com.example.ezyfood.models.Item;

import java.util.ArrayList;

public class Foods {
    public static ArrayList<Item> getFoods() {
        ArrayList<Item> foods = new ArrayList<>();
        foods.add(new Food("Fried Rice", 30000));
        foods.add(new Food("Fried Chicken", 25000));
        foods.add(new Food("Chicken Soup", 20000));

        return foods;
    }
}
