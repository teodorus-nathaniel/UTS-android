package com.example.ezyfood.data;

import com.example.ezyfood.models.Item;

import java.util.ArrayList;

public class Cart {
    public static ArrayList<Item> cartItems;
}
