package com.example.ezyfood.enums;

public enum ItemType {
    FOOD,
    DRINK,
    SNACK,
    TOPUP
}
