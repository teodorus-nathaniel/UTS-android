package com.example.ezyfood.models;

public class Food extends Item {
    public Food(String name, int price) {
        super(name, price);
    }
}
