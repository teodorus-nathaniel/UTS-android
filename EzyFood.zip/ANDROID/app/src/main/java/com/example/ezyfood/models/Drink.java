package com.example.ezyfood.models;

public class Drink extends Item {
    public Drink(String name, int price) {
        super(name, price);
    }
}
