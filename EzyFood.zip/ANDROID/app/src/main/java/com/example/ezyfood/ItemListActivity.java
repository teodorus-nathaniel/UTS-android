package com.example.ezyfood;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.ezyfood.data.Drinks;
import com.example.ezyfood.data.Foods;
import com.example.ezyfood.data.Snacks;
import com.example.ezyfood.enums.ItemType;
import com.example.ezyfood.models.Item;

import java.util.ArrayList;

public class ItemListActivity extends AppCompatActivity {

    ItemType type;
    ArrayList<Item> displayedItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_list);

        type = ItemType.values()[this.getIntent().getIntExtra(MainActivity.ITEM_TYPE, 0)];
        switch(type) {
            case FOOD:
                displayedItems = Foods.getFoods();
                break;
            case DRINK:
                displayedItems = Drinks.getDrinks();
                break;
            case SNACK:
                displayedItems = Snacks.getSnacks();
                break;
        }
    }

}
